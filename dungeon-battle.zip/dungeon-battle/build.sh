#!/bin/sh
g++ -std=c++17 -O2 src/main.cpp -o dungeon && echo "Built! Run with: ./dungeon"
