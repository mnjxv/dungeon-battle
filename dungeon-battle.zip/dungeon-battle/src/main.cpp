// Dungeon Battle - a simple turn-based C++ game
// Uses only the standard library, so it works on Windows, Mac and Linux.

#include <iostream>
#include <string>
#include <vector>
#include <random>
#include <limits>

std::mt19937 rng{std::random_device{}()};

int randomBetween(int low, int high) {
    std::uniform_int_distribution<int> dist(low, high);
    return dist(rng);
}

struct Fighter {
    std::string name;
    int hp;
    int maxHp;
    int minDmg;
    int maxDmg;
};

int readChoice(int low, int high) {
    int choice;
    while (true) {
        std::cout << "> ";
        if (std::cin >> choice && choice >= low && choice <= high) return choice;
        if (std::cin.eof()) std::exit(0);
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "Please enter a number from " << low << " to " << high << ".\n";
    }
}

Fighter makeMonster(int level) {
    const std::vector<std::string> names = {"Goblin", "Skeleton", "Orc", "Giant Spider", "Dark Mage"};
    std::string name = names[randomBetween(0, (int)names.size() - 1)];
    int hp = 20 + level * 8 + randomBetween(0, 10);
    return {name, hp, hp, 3 + level, 6 + level * 2};
}

void showStatus(const Fighter& player, const Fighter& monster, int potions) {
    std::cout << "\n----------------------------------\n";
    std::cout << player.name << "  HP: " << player.hp << "/" << player.maxHp
              << "   Potions: " << potions << "\n";
    std::cout << monster.name << "  HP: " << monster.hp << "/" << monster.maxHp << "\n";
    std::cout << "----------------------------------\n";
}

int main() {
    std::cout << "=== DUNGEON BATTLE ===\n";
    std::cout << "Enter your hero's name: ";
    std::string name;
    std::getline(std::cin, name);
    if (name.empty()) name = "Hero";

    Fighter player{name, 60, 60, 8, 14};
    int potions = 3;
    int level = 1;
    int kills = 0;

    while (player.hp > 0) {
        Fighter monster = makeMonster(level);
        std::cout << "\nA wild " << monster.name << " appears! (Room " << level << ")\n";
        bool defending = false;

        while (player.hp > 0 && monster.hp > 0) {
            showStatus(player, monster, potions);
            std::cout << "1) Attack   2) Defend   3) Use potion (+25 HP)   4) Run away\n";
            int choice = readChoice(1, 4);
            defending = false;

            if (choice == 1) {
                int dmg = randomBetween(player.minDmg, player.maxDmg);
                bool crit = randomBetween(1, 100) <= 15;
                if (crit) dmg *= 2;
                monster.hp -= dmg;
                std::cout << "You hit the " << monster.name << " for " << dmg
                          << (crit ? " damage. CRITICAL HIT!\n" : " damage.\n");
            } else if (choice == 2) {
                defending = true;
                std::cout << "You brace yourself. Damage is halved this turn.\n";
            } else if (choice == 3) {
                if (potions > 0) {
                    potions--;
                    int healed = std::min(25, player.maxHp - player.hp);
                    player.hp += healed;
                    std::cout << "You drink a potion and recover " << healed << " HP.\n";
                } else {
                    std::cout << "You have no potions left! You lose your turn.\n";
                }
            } else {
                if (randomBetween(1, 100) <= 50) {
                    std::cout << "You escaped to the next room!\n";
                    break;
                }
                std::cout << "You couldn't escape!\n";
            }

            if (monster.hp <= 0) break;

            // Monster's turn
            if (randomBetween(1, 100) <= 10) {
                std::cout << "The " << monster.name << " misses!\n";
            } else {
                int dmg = randomBetween(monster.minDmg, monster.maxDmg);
                if (defending) dmg /= 2;
                player.hp -= dmg;
                std::cout << "The " << monster.name << " hits you for " << dmg << " damage.\n";
            }
        }

        if (player.hp <= 0) break;

        if (monster.hp <= 0) {
            kills++;
            std::cout << "\nYou defeated the " << monster.name << "!\n";
            player.maxHp += 8;
            player.hp = std::min(player.maxHp, player.hp + 10);
            player.minDmg += 1;
            player.maxDmg += 2;
            std::cout << "You grow stronger! Max HP is now " << player.maxHp << ".\n";
            if (randomBetween(1, 100) <= 40) {
                potions++;
                std::cout << "The monster dropped a potion!\n";
            }
        }
        level++;
    }

    std::cout << "\n=== GAME OVER ===\n";
    std::cout << player.name << " fell in room " << level << " after defeating "
              << kills << " monsters.\n";
    return 0;
}
