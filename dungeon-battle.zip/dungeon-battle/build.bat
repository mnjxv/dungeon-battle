@echo off
g++ -std=c++17 -O2 src\main.cpp -o dungeon.exe
if %errorlevel%==0 (echo Built! Run dungeon.exe) else (echo Build failed. Make sure g++ is installed.)
pause
